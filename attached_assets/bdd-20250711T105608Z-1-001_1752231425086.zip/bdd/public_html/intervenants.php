<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Association Sportive - Intervenants et Séances</title>
    <style>
        /* Reset CSS */
        body, h1, h2, p, form {
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f2f2f2;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        header {
            background-color: #333;
            padding: 20px;
            text-align: center;
            margin-bottom: 20px;
        }

        h1 {
            margin: 0;
            font-size: 2em;
            color: #ECF0F1;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #3498db;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #ECF0F1;
        }

        form {
            width: 100%;
            max-width: 600px;
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 8px;
            box-sizing: border-box;
        }

        form input, form select {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            border-radius: 4px;
            transition: border-color 0.3s;
        }

        form input:focus, form select:focus {
            border-color: #3498db;
        }

        form input[type="submit"] {
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        form input[type="submit"]:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>

<header>
    <h1>Association Sportive</h1>
</header>


<?php
include('connexion.php');
$conn = connect();

if (!$conn) {
    die("La connexion à la base de données a échoué");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['addIntervenant'])) {
        $idIntervenant = isset($_POST['idIntervenant']) ? pg_escape_string($conn, $_POST['idIntervenant']) : null;
        $nom = isset($_POST['nom']) ? pg_escape_string($conn, $_POST['nom']) : '';
        $prenom = isset($_POST['prenom']) ? pg_escape_string($conn, $_POST['prenom']) : '';
        $idSeance = isset($_POST['idSeance']) ? pg_escape_string($conn, $_POST['idSeance']) : null;

        // on crée l'id de l'utilisateurs
        $indexation2="SELECT MAX(ID_Utilisateur) as maxid FROM Utilisateurs";
        $indexation1=pg_query($indexation2);
        $indexation0=pg_fetch_assoc($indexation1);
        $indexation=$indexation0['maxid'] +1;
        // // on crée l'id de l'intervenant
        // $indexation6="SELECT MAX(ID_Intervenant) as maxid FROM Intervenant";
        // $indexation5=pg_query($indexation6);
        // $indexation4=pg_fetch_assoc($indexation5);
        // $indexation3=$indexation4['maxid'] +1;


        if ($idIntervenant !== null && $idSeance !== null) {

            $insertSql2="INSERT INTO Utilisateurs(ID_Utilisateur,nomutilisateur,motdepasse,type_utilisateur) VALUES ($indexation,'$nom$prenom','postgres','admin')";
            $resultInsert2=pg_query($insertSql2);
            $insertSql = "INSERT INTO Intervenant (ID_Utilisateur,ID_Intervenant, Nom, Prenom, ID_Seance) VALUES ($indexation,$idIntervenant, '$nom', '$prenom', $idSeance)";
            $resultInsert = pg_query($conn, $insertSql);

            if ($resultInsert) {
                echo "<p>L'intervenant a été ajouté avec succès.</p>";
            } else {
                echo "<p>Erreur lors de l'ajout de l'intervenant: " . pg_last_error($conn) . "</p>";
            }
        } else {
            echo "<p>Erreur : L'ID de l'intervenant ou de la séance n'est pas fourni.</p>";
        }
    }
    elseif (isset($_POST['deleteIntervenant'])) {
        $idIntervenant = pg_escape_string($conn, $_POST['idIntervenant']);

        $deleteSql = "DELETE FROM Intervenant WHERE ID_Intervenant = $idIntervenant";
        $resultDelete = pg_query($conn, $deleteSql);

        if ($resultDelete) {
            echo "<p>L'intervenant a été supprimé avec succès.</p>";
        } else {
            echo "<p>Erreur lors de la suppression de l'intervenant: " . pg_last_error($conn) . "</p>";
        }
    }
}

$sql = "SELECT I.ID_Intervenant, I.Nom, I.Prenom, S.ID_Seance, C.nom_Activite, P.Jour, P.Heure, L.Nom_Lieu
        FROM Intervenant I
        JOIN Seance S ON I.ID_Seance = S.ID_Seance
        JOIN Cours C ON S.ID_cours = C.ID_cours
        JOIN Planning P ON I.ID_Seance = P.ID_Seance
        JOIN Lieu L ON S.Lieu = L.Lieu";

$result = pg_query($conn, $sql);

if ($result) {
    echo "<table>";
    echo "<tr><th>ID Intervenant</th><th>Nom</th><th>Prénom</th><th>ID Séance</th><th>Activité</th><th>Jour</th><th>Heure</th><th>Lieu</th></tr>";
    while ($row = pg_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['id_intervenant']}</td>
                <td>{$row['nom']}</td>
                <td>{$row['prenom']}</td>
                <td>{$row['id_seance']}</td>
                <td>{$row['nom_activite']}</td>
                <td>{$row['jour']}</td>
                <td>{$row['heure']}</td>
                <td>{$row['nom_lieu']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p>Aucun résultat trouvé: " . pg_last_error($conn) . "</p>";
}

pg_close($conn);
?>

<!-- Form to add an intervenant -->
<form method="post">
    <h2>Ajouter un intervenant</h2>
    ID Intervenant: <input type="number" name="idIntervenant" required>
    Nom: <input type="text" name="nom" required>
    Prénom: <input type="text" name="prenom" required>
    ID Séance: <input type="number" name="idSeance" required>
    <input type="submit" name="addIntervenant" value="Ajouter Intervenant">
</form>

<!-- Form to delete an intervenant -->
<form method="post">
    <h2>Supprimer un intervenant</h2>
    ID Intervenant: <input type="number" name="idIntervenant" required>
    <input type="submit" name="deleteIntervenant" value="Supprimer Intervenant">
</form>

</body>
</html>
