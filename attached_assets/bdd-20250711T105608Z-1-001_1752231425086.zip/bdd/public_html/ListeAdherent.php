<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Adhérents</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            background-color: #f9f9f9;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: #ffffff;
            color: #333;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f0f0f0;
        }
        form {
            margin-top: 20px;
        }
        h2 {
            color: #333;
            border-bottom: 2px solid #3498db;
            padding-bottom: 5px;
            margin-bottom: 20px;
        }
        input[type="text"], input[type="number"], select {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            border-radius: 4px;
            transition: border-color 0.3s;
        }
        input[type="text"]:focus, input[type="number"]:focus, select:focus {
            border-color: #3498db;
        }
        input[type="submit"] {
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #2980b9;
        }
        .supprimer-form {
            display: inline-block;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        p {
            margin: 10px 0;
        }
        .success {
            color: #27ae60;
        }
        .error {
            color: #c0392b;
        }
        .info {
            color: #3498db;
        }
    </style>
</head>
<body>

<div class="container">

    <?php
    include("connexion.php");
    $con = connect();

    if (!$con) {
        echo "Problème connexion à la base";
        exit;
    }

    // Vérifier si le formulaire d'ajout a été soumis
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Récupérer les données du formulaire
        $nom = $_POST["nom"];
        $prenom = $_POST["prenom"];
        $sexe = $_POST["sexe"];
        $age = $_POST["age"];

        // Supprimer un adhérent si l'ID est spécifié
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == 'supprimer') {
            $ID_AdherentASupprimer = $_POST['ID_AdherentASupprimer'];
            $ID_UtilisateurASupprimer=$_POST['ID_UtilisateurASupprimer'];
            $sqlSuppression = "DELETE FROM Adherent WHERE id_adherent = $ID_AdherentASupprimer";

            $sqlSuppression_U="DELETE FROM Utilisateurs WHERE ID_Utilisateur=$ID_UtilisateurASupprimer";
            $resultatSuppression = pg_query($sqlSuppression);
            $reultatSuppression_U=pg_query($sqlSuppression_U);

            if ($resultatSuppression) {
                echo "<p class='success'>Adhérent supprimé avec succès.</p>";
            } else {
                echo "<p class='error'>Erreur lors de la suppression de l'adhérent.</p>";
            }
        }

        // Vérifier si les champs ne sont pas vides
        if (!empty($nom) && !empty($prenom) && !empty($sexe) && !empty($age)) {
            // Récupérer le plus grand ID existant
            $sqlMaxID_U="SELECT MAX(ID_Utilisateur) AS maxID_U FROM Utilisateurs";
            $sqlMaxID = "SELECT MAX(ID_Adherent) AS maxID FROM Adherent";
            $resultatMaxID_U=pg_query($sqlMaxID_U);
            $resultatMaxID = pg_query($sqlMaxID);
            $rowMaxID = pg_fetch_assoc($resultatMaxID);
            $rowMaxID_U=pg_fetch_assoc($resultatMaxID_U);
            $nouvelID = $rowMaxID['maxid'] + 1; // incremente le plus grand des ID de 1 pour
            $nouvelID_Utilisateur = $rowMaxID_U['maxid_u']+1;
            //toujours avoir un ID unique

            // Ajout du nouvel Utilisateur
            $sqlAjoutUtilisateur = "INSERT INTO Utilisateurs (ID_Utilisateur,nomutilisateur,motdepasse,type_utilisateur) VALUES ($nouvelID_Utilisateur,'$nom.$prenom','postgres','adherent')";
            $resultatAjout2=pg_query($sqlAjoutUtilisateur);

            // Ajouter l'adhérent avec le nouvel ID
            $sqlAjoutAdherent = "INSERT INTO Adherent (ID_Utilisateur,ID_Adherent, Nom, Prenom, Sexe, Age) VALUES ($nouvelID_Utilisateur,$nouvelID, '$nom', '$prenom', '$sexe', $age)";
            $resultatAjout = pg_query($sqlAjoutAdherent);

            if ($resultatAjout) {
                echo "<p class='success'>Nouvel adhérent ajouté avec succès.</p>";
            } else {
                echo "<p class='error'>Erreur lors de l'ajout de l'adhérent.</p>";
            }
        } else {
            echo "<p class='error'>Tous les champs doivent être remplis.</p>";
        }
    }

    // Afficher la liste des adhérents
    $sqlListeAdherents = "SELECT ID_Utilisateur,nom, Prenom,id_adherent,sexe,age FROM Adherent";
    $resultatListeAdherents = pg_query($sqlListeAdherents);

    if (!$resultatListeAdherents) {
        echo "Problème lors du lancement de la requête";
        exit;
    }

    // Vérifier si des résultats sont disponibles
    if (pg_num_rows($resultatListeAdherents) > 0) {
        echo "<h2>Liste des Adhérents</h2>";
        echo "<table>";
        echo "<tr><th>Nom</th><th>Prénom</th><th>Sexe</th><th>Âge</th><th>Action</th></tr>";

        while ($ligne = pg_fetch_array($resultatListeAdherents)) {
            echo "<tr>";
            echo "<td>" . $ligne['nom'] . "</td>";
            echo "<td>" . $ligne['prenom'] . "</td>";
            echo "<td>" . $ligne['sexe'] . "</td>";
            echo "<td>" . $ligne['age'] . "</td>";
            echo "<td>
                    <form method='post' class='supprimer-form' action='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "' onsubmit='return confirm(\"Êtes-vous sûr de vouloir supprimer cet adhérent ?\")'>
                        <input type='hidden' name='ID_AdherentASupprimer' value='" . $ligne['id_adherent'] . "'>
                        <input type='hidden' name='ID_UtilisateurASupprimer' value='" . $ligne['id_utilisateur'] . "'>
                        <input type='submit' value='Supprimer'>
                        <input type='hidden' name='action' value='supprimer'>
                    </form>
                  </td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p class='info'>Aucun adhérent trouvé.</p>";
    }

    pg_close($con);
    ?>

    <!-- Formulaire d'ajout d'adhérent -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <h2>Ajouter un Adhérent</h2>
        <label for="nom">Nom:</label>
        <input type="text" name="nom" required>
        <br>
        <label for="prenom">Prénom:</label>
        <input type="text" name="prenom" required>
        <br>
        <label for="sexe">Sexe:</label>
        <select name="sexe" required>
            <option value="M">Homme</option>
            <option value="F">Femme</option>
        </select>
        <br>
        <label for="age">Âge:</label>
        <input type="number" name="age" required>
        <br>
        <input type="submit" value="Ajouter Adhérent">
    </form>

</div>

</body>
</html>
