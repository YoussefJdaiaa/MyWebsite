<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planning des Séances</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #666666;
            color: #ffffff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            min-height: 100vh;
        }

        h2 {
            margin-bottom: 20px;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            background-color: #333;
            margin-bottom: 20px;
            color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #505050;
        }

        tr:nth-child(even) {
            background-color: #404040;
        }

        @media (max-width: 768px) {
            body {
                padding: 10px;
            }

            table {
                width: 95%;
            }
        }
    </style>
</head>
<body>

<?php
include("connexion.php");
$con = connect();

if (!$con) {
    echo "Problème de connexion à la base de données";
    exit;
}

$sql = "SELECT Cours.nom_Activite, Lieu.Nom_Lieu, Intervenant.Nom AS Nom_Intervenant, Intervenant.Prenom AS Prenom_Intervenant, Planning.Jour, Planning.Heure FROM Planning JOIN Seance ON Planning.ID_Seance = Seance.ID_Seance JOIN Cours ON Seance.ID_cours = Cours.ID_cours JOIN Lieu ON Seance.Lieu = Lieu.Lieu JOIN Intervenant ON Seance.ID_Seance = Intervenant.ID_Seance";
$resultat = pg_query($con, $sql);

if (!$resultat) {
    echo "<p>Problème lors de l'exécution de la requête</p>";
    exit;
}

if (pg_num_rows($resultat) > 0) {
    echo "<h2>Planning des Séances</h2>";
    echo "<table>";
    echo "<tr><th>Activité</th><th>Lieu</th><th>Intervenant Responsable</th><th>Jour</th><th>Heure</th></tr>";

    while ($ligne = pg_fetch_assoc($resultat)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($ligne['nom_activite']) . "</td>";
        echo "<td>" . htmlspecialchars($ligne['nom_lieu']) . "</td>";
        echo "<td>" . htmlspecialchars($ligne['nom_intervenant']) . " " . htmlspecialchars($ligne['prenom_intervenant']) . "</td>";
        echo "<td>" . htmlspecialchars($ligne['jour']) . "</td>";
        echo "<td>" . htmlspecialchars($ligne['heure']) . "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "<p>Aucun planning trouvé.</p>";
}

pg_close($con);
?>
</body>
</html>
