
<?php
include("connexion.php");
$con = connect();

if (!$con) {
    echo "Problème connexion à la base";
    exit;
}

$sql = "SELECT ID_cours, nom_Activite, Nom_Lieu FROM Cours
        JOIN Lieu ON Cours.Lieu = Lieu.Lieu";
$resultat = pg_query($con, $sql);

if (!$resultat) {
    echo "Problème lors du lancement de la requête";
    exit;
}

// Vérifier si des résultats sont disponibles
if (pg_num_rows($resultat) > 0) {
    echo "<table>";
    echo "<tr><th>Course ID</th><th>Course Name</th><th>Location</th></tr>";

    while ($ligne = pg_fetch_assoc($resultat)) {
        echo "<tr>";
        echo "<td>" . $ligne['id_cours'] . "</td>";
        echo "<td>" . $ligne['nom_activite'] . "</td>";
        echo "<td>" . $ligne['nom_lieu'] . "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "Aucun cours trouvé.";
}

pg_close($con);
?>

</body>
</html>

