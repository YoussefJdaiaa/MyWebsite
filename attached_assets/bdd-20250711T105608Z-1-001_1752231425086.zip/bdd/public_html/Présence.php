<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Présences</title>
    <style>
        body {
            background-color: #666666;
            color: #ffffff;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            padding: 20px;
            text-align: center;
        }

        h1, h2 {
            margin: 0;
            color: #ECF0F1;
        }

        h1 {
            font-size: 2em;
        }

        h2 {
            margin-top: 20px;
            text-align: center;
        }

        form {
            margin: 20px auto;
            text-align: center;
        }

        label, select, input[type=number], input[type=checkbox], input[type=submit] {
            margin: 5px;
        }

        select, input[type=number], input[type=submit] {
            padding: 5px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        th {
            background-color: #67D8F2;
            color: black;
        }

        tr:nth-child(even) {
            background-color: #ECF0F1;
            color: black;
        }
    </style>
</head>
<body>

<header>
    <h1>Gestion des Présences</h1>
</header>

<?php
include("connexion.php");
$con = connect();

if (!$con) {
    echo "Problème de connexion à la base de données";
    exit;
}

$sqlSeances = "SELECT Seance.ID_Seance, Cours.nom_Activite, Planning.Jour, Planning.Heure
               FROM Seance
               JOIN Cours ON Seance.ID_cours = Cours.ID_cours
               JOIN Planning ON Seance.ID_Seance = Planning.ID_Seance
               ORDER BY Seance.ID_Seance";
$resultatSeances = pg_query($con, $sqlSeances);

if (!$resultatSeances) {
    echo "Problème lors du lancement de la requête pour les séances: " . pg_last_error($con);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["validerPresence"])) {
    $idSeance = $_POST["seance"];
    $jour = $_POST["jour"]; // Retrieve day input from form
    $mois = $_POST["mois"]; // Retrieve month input from form
    $presences = isset($_POST["presence"]) ? $_POST["presence"] : [];
    $absences = isset($_POST["absence"]) ? $_POST["absence"] : [];

    foreach ($presences as $idAdherent => $estPresent) {
        $estPresentBoolean = $estPresent == '1' ? 'true' : 'false';
        $insertQuery = "INSERT INTO Presence (ID_Adherent, ID_Seance, Jour, Mois, EstPresent) VALUES ($idAdherent, $idSeance, $jour, $mois, $estPresentBoolean)";
        pg_query($con, $insertQuery);
    }

    foreach ($absences as $idAdherent => $estAbsent) {
        $estAbsentBoolean = $estAbsent == '1' ? 'true' : 'false';
        $insertQuery = "INSERT INTO Presence (ID_Adherent, ID_Seance, Jour, Mois, EstPresent, EstAbsent) VALUES ($idAdherent, $idSeance, $jour, $mois, false, $estAbsentBoolean)";
        pg_query($con, $insertQuery);
    }

    echo "Présences et absences enregistrées avec succès!";
}
?>

<form method="post">
    <label for="seance">Sélectionnez une séance :</label>
    <select name="seance" onchange="this.form.submit()">
        <?php while ($rowSeance = pg_fetch_assoc($resultatSeances)) : ?>
            <option value="<?php echo $rowSeance['id_seance']; ?>">
                <?php echo $rowSeance['nom_activite'] . " - " . $rowSeance['jour'] . " - " . $rowSeance['heure']; ?>
            </option>
        <?php endwhile; ?>
    </select>
</form>

<?php
if (isset($_POST['seance'])) {
    $idSeanceSelected = $_POST['seance'];

    $sqlAdherents = "SELECT Adherent.ID_Adherent, Adherent.Nom, Adherent.Prenom
                     FROM Adherent
                     JOIN EstInscrit ON Adherent.ID_Adherent = EstInscrit.ID_Adherent
                     WHERE EstInscrit.ID_Seance = $idSeanceSelected";
    $resultatAdherents = pg_query($con, $sqlAdherents);

    if (!$resultatAdherents) {
        echo "Problème lors de la récupération des adhérents inscrits à la séance: " . pg_last_error($con);
        exit;
    }

    echo "<form method='post'>";
    echo "<input type='hidden' name='seance' value='$idSeanceSelected'>";
    echo "<label for='jour'>Jour :</label>";
    echo "<input type='number' name='jour' required>";
    echo "<label for='mois'>Mois :</label>";
    echo "<input type='number' name='mois' required>";

    echo "<h3>Liste des adhérents pour la séance sélectionnée :</h3>";

    while ($rowAdherent = pg_fetch_assoc($resultatAdherents)) {
        $sqlAbsences = "SELECT COUNT(*) AS nb_absences
                        FROM Presence
                        WHERE ID_Adherent = {$rowAdherent['id_adherent']}
                        AND ID_Seance = $idSeanceSelected
                        AND EstPresent = false";
        $resultatAbsences = pg_query($con, $sqlAbsences);
        $rowAbsences = pg_fetch_assoc($resultatAbsences);
        $nbAbsences = $rowAbsences['nb_absences'];

        echo "<div>";
        echo htmlspecialchars($rowAdherent['prenom']) . " " . htmlspecialchars($rowAdherent['nom']) . " - Absences: " . $nbAbsences;
        echo "<input type='checkbox' name='presence[" . $rowAdherent['id_adherent'] . "]' value='1' onclick='uncheckAbsence(" . $rowAdherent['id_adherent'] . ")'> Présent";
        echo "<input type='checkbox' name='absence[" . $rowAdherent['id_adherent'] . "]' value='1'> Absent";
        echo "</div>";
    }

    echo "<input type='submit' name='validerPresence' value='Valider les présences'>";
    echo "</form>";
}
?>

<script>
    function uncheckAbsence(adherentId) {
        var absenceCheckbox = document.querySelector("input[name='absence[" + adherentId + "]']");
        if (absenceCheckbox.checked) {
            absenceCheckbox.checked = false;
        }
    }
</script>

</body>
</html>

