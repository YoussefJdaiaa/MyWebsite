<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Association Sportive</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em 0;
        }

        main {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
        }

        p {
            line-height: 1.6;
            color: #555;
        }

        .sport {
            margin-bottom: 30px;
        }

        .sport img {
            max-width: 100%;
            height: auto;
        }

        footer {
            background-color: #333;
            color: #FDFEFE;
            text-align: center;
            padding: 1em 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

    <header>
        <h1>Association Sportive</h1>
    </header>

    <main>
        <div class="sport">
            <h2>Course à Pied (10 et 20km)</h2>
            <img src="course-a-pied.jpg" alt="Course à Pied">
            <p>La course à pied au sein de notre association sportive est une discipline passionnante qui englobe à la fois le plaisir de courir, la formation structurée et la participation à des compétitions stimulantes. Nous offrons des programmes d'entraînement spécifiques axés sur les distances de 10 km et 20 km, adaptés à tous les niveaux, du coureur débutant au coureur expérimenté.

Nos intervenants compétents sont des professionnels de la course à pied, partageant une passion commune pour ce sport. Ils sont dédiés à guider nos adhérents à travers des séances d'entraînement variées, comprenant des séances de vitesse, d'endurance et de renforcement musculaire. Leur expertise garantit un développement progressif des compétences de course, tout en minimisant les risques de blessures.

Au-delà des entraînements réguliers, notre association favorise la participation à des compétitions locales et nationales. Nous encourageons nos membres à relever des défis personnels en participant à des courses officielles de 10 km et 20 km. Ces événements sont des opportunités excitantes pour tester ses limites, mesurer ses progrès et ressentir l'enthousiasme de la compétition.

Notre association ne se limite pas seulement à la participation individuelle aux courses, mais elle organise également des événements internes et participe à des compétitions en équipe. Ces initiatives renforcent le sentiment d'appartenance à une communauté sportive dynamique, où le partage des succès et l'encouragement mutuel sont au cœur de nos valeurs.

Rejoindre notre groupe de course à pied au sein de l'association offre bien plus que des entraînements physiques. C'est une opportunité de construire des amitiés durables, de se dépasser soi-même et de vivre une expérience sportive enrichissante. Nous sommes fiers de promouvoir un mode de vie sain et actif à travers la passion commune de la course à pied au sein de notre association sportive.</p>
        </div>

        <div class="sport">
            <h2>Natation</h2>
            <img src="natation.jpg" alt="Natation">
            <p>La natation au sein de notre association sportive offre une expérience aquatique complète, alliant la formation technique, la condition physique et la participation à des compétitions stimulantes. Nous proposons des programmes d'entraînement spécialisés, avec un accent particulier sur les différentes disciplines de la natation, adaptés à tous les niveaux, du nageur débutant au nageur confirmé.

Nos instructeurs qualifiés sont des experts dans le domaine de la natation, passionnés par l'enseignement des techniques de nage et l'amélioration des performances. Les sessions d'entraînement incluent des exercices de natation, des séances de renforcement musculaire spécifique et des conseils sur la respiration et la technique de virage. Ces cours sont conçus pour aider nos membres à perfectionner leur style de nage et à développer leur endurance.

En plus des séances d'entraînement régulières, notre association encourage la participation à des compétitions locales et nationales de natation. Nous soutenons nos nageurs dans leur désir de se mesurer aux autres en compétition officielle. Cela inclut des épreuves individuelles et par équipe, offrant à nos membres la chance de repousser leurs limites dans un environnement compétitif stimulant.

Notre association ne se limite pas seulement à la compétition individuelle ; nous organisons également des événements internes et participons à des compétitions en équipe. Ces moments renforcent le sentiment de camaraderie et l'esprit d'équipe parmi nos nageurs.

Rejoindre notre groupe de natation au sein de l'association offre bien plus que des compétences en natation. C'est une occasion de s'immerger dans une communauté dédiée à l'amélioration personnelle, à la compétition sportive et à la passion partagée pour la natation. Nous sommes fiers de promouvoir un mode de vie sain et actif à travers l'exploration de l'eau au sein de notre association sportive.</p>
        </div>

        <div class="sport">
            <h2>Triathlon</h2>
            <img src="triathlon.jpg" alt="Triathlon">
            <p>
La pratique du triathlon au sein de notre association sportive offre une expérience unique qui allie trois disciplines exigeantes : la natation, le cyclisme et la course à pied. Nos programmes d'entraînement spécialisés sont conçus pour les triathlètes de tous niveaux, qu'ils soient novices ou expérimentés, et visent à développer leurs compétences dans chacune des disciplines.

Notre équipe d'instructeurs compétents est composée d'experts dans les domaines de la natation, du cyclisme et de la course à pied. Ils guident nos membres à travers des séances d'entraînement variées, incluant des entraînements spécifiques à chaque discipline ainsi que des transitions entre les différentes phases du triathlon. Ces instructeurs sont déterminés à aider nos triathlètes à atteindre leurs objectifs de performance et à progresser dans l'ensemble des compétences requises.

Au-delà des entraînements réguliers, notre association encourage activement la participation à des compétitions de triathlon, allant des épreuves locales aux compétitions nationales voire internationales. Nous soutenons nos triathlètes dans la préparation de leurs courses, que ce soit pour des sprints, des distances olympiques ou des épreuves de longue distance. La diversité des compétitions permet à chacun de trouver des défis adaptés à ses ambitions personnelles.

Notre association favorise également un esprit d'équipe et d'entraide entre les triathlètes. Nous organisons des sessions d'entraînement collectives, des événements internes et des participations à des relais de triathlon pour renforcer le sentiment d'appartenance à une communauté sportive dynamique.

Rejoindre notre groupe de triathlon au sein de l'association offre bien plus qu'une simple pratique sportive. C'est une immersion dans une discipline multi-facettes, une opportunité de repousser ses limites et de vivre une expérience complète de dépassement de soi au sein d'une communauté engagée. Nous sommes fiers de promouvoir un mode de vie actif et équilibré à travers la pratique du triathlon au sein de notre association sportive.</p>
        </div>

        <div class="sport">
            <h2>Gymnastique</h2>
            <img src="gymnastique.jpg" alt="Gymnastique">
            <p>La gymnastique au sein de notre association sportive offre une expérience dynamique qui allie la force, la flexibilité, la coordination et l'élégance. Nos programmes de gymnastique sont conçus pour accueillir un large éventail de niveaux, allant des débutants aux gymnastes plus avancés, et visent à développer des compétences variées à travers différentes disciplines gymniques.

Nos instructeurs compétents sont des experts dans le domaine de la gymnastique, apportant avec eux une passion pour l'enseignement des mouvements précis et des techniques spécifiques. Les séances d'entraînement incluent une diversité d'exercices, allant des éléments de base de la gymnastique artistique à des routines plus complexes qui mettent l'accent sur la force, la souplesse et la grâce.

Au-delà des entraînements réguliers, notre association encourage la participation à des compétitions de gymnastique, permettant aux gymnastes de présenter leurs compétences devant un public et de mesurer leur progression par rapport à d'autres athlètes. Ces compétitions peuvent couvrir différentes catégories, adaptées aux différents niveaux et âges de nos membres.

Notre association favorise également un esprit d'équipe et de camaraderie au sein de notre groupe de gymnastique. Nous organisons des événements internes, des démonstrations et des ateliers pour renforcer le sentiment d'appartenance à une communauté sportive dédiée à l'excellence gymnique.

Rejoindre notre groupe de gymnastique au sein de l'association offre bien plus qu'une simple pratique sportive. C'est une immersion dans le monde captivant de la gymnastique, une occasion de développer des compétences physiques et mentales, et de participer à une communauté engagée. Nous sommes fiers de promouvoir un mode de vie actif et artistique à travers la pratique de la gymnastique au sein de notre association sportive.





</p>
        </div>

        <div class="sport">
            <h2>Stretching</h2>
            <img src="stretching.jpg" alt="Stretching">
            <p>La pratique du stretching au sein de notre association sportive offre une approche essentielle pour améliorer la flexibilité, réduire la tension musculaire et favoriser le bien-être physique. Nos programmes de stretching sont conçus pour tous, qu'ils soient débutants ou pratiquants réguliers, et visent à promouvoir la détente corporelle et la prévention des blessures.

Nos instructeurs qualifiés dans le domaine du stretching sont dédiés à guider nos membres à travers des séances structurées axées sur la mobilité et la relaxation. Ces sessions incluent une variété d'étirements statiques et dynamiques, ainsi que des exercices de respiration et de relaxation. Les instructeurs mettent l'accent sur des techniques de stretching sûres et efficaces pour aider nos membres à atteindre leurs objectifs de souplesse.

Au-delà des bienfaits physiques, la pratique régulière du stretching contribue à la gestion du stress, à l'amélioration de la posture et à une meilleure conscience corporelle. Notre association favorise une approche holistique du bien-être, en intégrant des séances de stretching dans un environnement encourageant et détendu.

Nos membres ont également la possibilité de participer à des ateliers spécifiques, abordant des techniques avancées de stretching et des méthodes complémentaires telles que le yoga. Ces opportunités offrent une expérience approfondie pour ceux qui souhaitent explorer davantage les bienfaits du stretching.

Rejoindre notre groupe de stretching au sein de l'association offre bien plus qu'une simple pratique physique. C'est une invitation à prendre soin de son corps, à améliorer sa souplesse et à cultiver un état d'esprit calme et équilibré. Nous sommes fiers de promouvoir un mode de vie sain et détendu à travers la pratique du stretching au sein de notre association sportive.</p>
        </div>
    </main>

    <footer>
        <p>Ensemble, Créons la Réussite</p>
    </footer>

</body>
</html>
