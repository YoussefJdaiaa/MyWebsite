<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Association Sportive - Adhérents</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #495057;
        }

        header {
            background-color: #343a40;
            color: #ffffff;
            text-align: center;
            padding: 20px;
        }

        nav {
            background-color: #e9ecef;
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ced4da;
        }

        nav a {
            color: #495057;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #007bff;
        }

        section {
            margin: 20px;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #007bff;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 10px;
            background-color: #f1f1f1;
            padding: 15px;
            border-radius: 8px;
            color: #495057;
            transition: background-color 0.3s ease;
        }

        li:hover {
            background-color: #d5d8dc;
        }

        footer {
            background-color: #343a40;
            color: #ffffff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<header>
    <h1>Association Sportive</h1>
</header>

<nav>
    <a href="#">Accueil</a>
    <a href="Planning.php">Planning</a>
    <a href="Competition.php">Compétition</a>
</nav>

<section>
    <h2>Descriptions des Cours</h2>
    <ul>
        <?php
        // Connexion à la base de données
        include_once("connexion.php");
        $con = connect();

        // Vérification de la connexion
        if (!$con) {
            echo "Problème connexion à la base";
            exit;
        }

        // Récupération de tous les noms d'activités depuis la base de données
        $sqlActivites = "SELECT nom_activite, id_cours FROM Cours";
        $resultatActivites = pg_query($sqlActivites);

        // Affichage des noms d'activités dans la liste avec un lien vers description_activite.php
        while ($rowActivite = pg_fetch_assoc($resultatActivites)) {
            echo "<li><a href='description_activite.php?id={$rowActivite['id_cours']}'>" . $rowActivite['nom_activite'] . "</a></li>";
        }
        ?>
    </ul>
</section>

<section>
    <h2>Vos Cours Inscrits</h2>
    <ul>
        <?php
        // Connexion à la base de données
        include_once("connexion.php");
        $con = connect();

        // Vérification de la connexion
        if (!$con) {
            echo "Problème connexion à la base";
            exit;
        }

        // Récupérer l'ID_Utilisateur depuis la session
        $ID_Utilisateur = $_SESSION['ID_Utilisateur'];

        $sqlRecupererIdAdherent;
        if ($ID_Utilisateur !== null) {
            // Récupérer l'ID_Adherent associé à l'utilisateur
            $sqlRecupererIdAdherent = "SELECT ID_Adherent FROM Adherent WHERE ID_Utilisateur = $ID_Utilisateur";
        } else {
            echo "ID_Utilisateur non trouvé dans la session.";
        }

        // Récupération des cours inscrits de l'adhérent depuis la table estinscrit et planning
        $ID_Adherent1 = pg_query($sqlRecupererIdAdherent);
        $ID_Adherent2 = pg_fetch_assoc($ID_Adherent1);
        $ID_Adherent = $ID_Adherent2['id_adherent'];

        $sqlInscrits = "SELECT Cours.nom_activite, Planning.Jour, Planning.Heure
                        FROM estinscrit
                        JOIN Seance ON estinscrit.ID_Seance = Seance.ID_Seance
                        JOIN Cours ON Seance.ID_Cours = Cours.ID_Cours
                        JOIN Planning ON estinscrit.ID_Seance = Planning.ID_Seance
                        WHERE estinscrit.ID_Adherent = $ID_Adherent";

        $resultatInscrits = pg_query($con, $sqlInscrits);

        if ($resultatInscrits === false) {
            echo "Erreur de requête SQL : " . pg_last_error($con);
            exit;
        }

        while ($rowInscrit = pg_fetch_assoc($resultatInscrits)) {
            echo "<li>{$rowInscrit['nom_activite']} - {$rowInscrit['jour']} à {$rowInscrit['heure']}</li>";
        }

        pg_close($con);
        ?>
    </ul>
</section>

<footer>
    <p>&copy; 2023 Association Sportive. Tous droits réservés.</p>
</footer>

</body>
</html>
