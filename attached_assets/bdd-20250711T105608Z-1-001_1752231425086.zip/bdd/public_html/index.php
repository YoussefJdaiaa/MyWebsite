<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Association Sportive - Connexion</title>
    <style>
        body {
            background: linear-gradient(145deg, #575757, #333333);
            color: #ffffff;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            overflow: hidden;
        }

        header {
            position: absolute;
            top: 0;
            width: 100%;
            background-color: rgba(51, 51, 51, 0.85);
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }

        header h1 {
            margin: 0;
            font-size: 2.2em;
            color: #E2E2E2;
        }

        .container {
            width: 320px;
            background-color: rgba(51, 51, 51, 0.95);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.7);
            border: 1px solid #67D8F2;
            backdrop-filter: blur(5px);
        }

        .container h2 {
            font-size: 1.8em;
            color: #E2E2E2;
            margin-bottom: 30px;
            position: relative;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
        }

        input[type="text"],
        input[type="password"] {
            width: calc(100% - 20px);
            padding: 12px 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: none;
            background: rgba(255, 255, 255, 0.2);
            color: #FFF;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            background: rgba(255, 255, 255, 0.3);
            outline: none;
        }

        .btn {
            width: 100%;
            padding: 12px 10px;
            text-align: center;
            border: none;
            border-radius: 5px;
            background-image: linear-gradient(45deg, #67D8F2, #2C3E50);
            color: #ffffff;
            cursor: pointer;
            transition: opacity 0.3s, transform 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .btn:hover {
            opacity: 0.9;
            transform: scale(1.05);
        }
    </style>
</head>
<body>

<header>
    <h1>Association Sportive</h1>
</header>

<div class="container">
    <h2>Connexion</h2>
    <form method="post" action="traitement_login.php">
        <input type="text" name="identifiant" placeholder="Identifiant" required><br>
        <input type="password" name="mot_de_passe" placeholder="Mot de passe" required><br>
        <input type="submit" class="btn" value="Se connecter">
    </form>
</div>

</body>
</html>
