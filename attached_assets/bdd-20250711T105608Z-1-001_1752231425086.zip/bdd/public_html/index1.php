<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Association Sportive - Adhérents</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #495057;
        }

        header {
            background-color: #343a40;
            color: #ffffff;
            text-align: center;
            padding: 20px;
        }

        nav {
            background-color: #e9ecef;
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ced4da;
        }

        nav a {
            color: #495057;
            text-decoration: none;
            padding: 10px;
            margin: 0 10px;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #007bff;
        }

        section {
            margin: 20px;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #007bff;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 10px;
            background-color: #f1f1f1;
            padding: 15px;
            border-radius: 8px;
            color: #495057;
            transition: background-color 0.3s ease;
        }

        li:hover {
            background-color: #d5d8dc;
        }

        footer {
            background-color: #343a40;
            color: #ffffff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<header>
    <h1>Association Sportive</h1>
</header>

<nav>
    <a href="#">Accueil</a>
    <a href="ListeAdherent.php">Adhérents</a>
    <a href="Planning.php">Planning</a>
    <a href="Competition.php">Compétition</a>
    <a href="Présence.php">Présence</a>
    <a href="Séance.php">Séance</a>
    <a href="intervenants.php">Intervenants</a>
</nav>

<section>
    <h2>Liste des Cours Disponibles</h2>
    <ul>
        <?php
        // Connexion à la base de données
        include("connexion.php");
        $con = connect();

        // Vérification de la connexion
        if (!$con) {
            echo "Problème connexion à la base";
            exit;
        }

        // Récupération des noms de cours depuis la base de données
        $sqlCours = "SELECT nom_activite,id_cours FROM Cours";
        $resultatCours = pg_query($sqlCours);

        // Affichage des cours dans la liste
        while ($rowCours = pg_fetch_assoc($resultatCours)) {
          echo "<li><a href='description_activite.php?id={$rowCours['id_cours']}'>" . $rowCours['nom_activite'] . "</a></li>";
        }

        // Fermeture de la connexion
        pg_close($con);
        ?>
    </ul>
</section>

</body>
</html>
