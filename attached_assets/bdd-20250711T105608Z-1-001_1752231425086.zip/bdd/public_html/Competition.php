<?php
include("connexion.php");
$con = connect();

if (!$con) {
    echo "Problème connexion à la base";
    exit;
}

// Requête pour obtenir les informations sur les compétitions
$competitionQuery = "SELECT NomCompetition, Lieu.Nom_Lieu, Date, Categorie FROM Competition JOIN Lieu ON Competition.Lieu = Lieu.Lieu";
$resultat = pg_query($con, $competitionQuery);

if (!$resultat) {
    echo "Problème lors du lancement de la requête pour les compétitions";
    exit;
}

// Vérifier si des résultats sont disponibles
if (pg_num_rows($resultat) > 0) {
    ?>

    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Liste des Compétitions</title>
        <style>
            /* General styling */
            body {
                background: linear-gradient(145deg, #575757, #333333);
                color: #ffffff;
                font-family: 'Arial', sans-serif;
                margin: 0;
                padding: 20px;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
            }

            /* Styling for the main container */
            .container {
                background-color: rgba(51, 51, 51, 0.9);
                padding: 25px;
                border-radius: 15px;
                box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
                max-width: 800px;
                width: 90%;
                margin-top: 30px;
            }

            /* Styling for headings */
            h2 {
                color: #ECF0F1;
                font-size: 1.8em;
                margin-bottom: 15px;
                text-align: center;
                padding-bottom: 10px;
                border-bottom: 2px solid #67D8F2;
            }

            /* Table styling */
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }

            th, td {
                padding: 10px;
                border: 1px solid #ddd;
                text-align: left;
            }

            th {
                background-color: #505050;
                color: #ffffff;
            }

            tr:nth-child(even) {
                background-color: #404040;
            }

            /* Button styling */
            .resultatButton {
                display: block;
                margin-top: 20px;
                padding: 10px;
                background-color: #67D8F2;
                color: #333;
                text-align: center;
                text-decoration: none;
                font-size: 16px;
                border-radius: 5px;
                cursor: pointer;
                width: fit-content;
                align-self: center;
            }

            .resultatButton:hover {
                background-color: #2C3E50;
                color: #ffffff;
            }

        </style>
    </head>
    <body>

    <div class="container">
        <h2>Liste des Compétitions</h2>
        <table>
            <tr>
                <th>Nom Compétition</th>
                <th>Lieu</th>
                <th>Date</th>
                <th>Catégorie</th>
            </tr>
            <?php
            while ($ligne = pg_fetch_assoc($resultat)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($ligne['nomcompetition']) . "</td>";
                echo "<td>" . htmlspecialchars($ligne['nom_lieu']) . "</td>";
                echo "<td>" . htmlspecialchars($ligne['date']) . "</td>";
                echo "<td>" . htmlspecialchars($ligne['categorie']) . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
        <a href='Resultat.php' class='resultatButton'>Résultats des Compétitions Précédentes</a>
    </div>

    </body>
    </html>

    <?php
} else {
    echo "Aucune compétition trouvée.";
}

pg_close($con);
?>
