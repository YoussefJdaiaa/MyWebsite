<?php
session_start();

include("connexion.php");
$con = connect();

if (!$con) {
    echo "Problème connexion à la base";
    exit;
}

$identifiant = $_POST['identifiant'];
$mot_de_passe = $_POST['mot_de_passe'];

$utilisateur_trouve = false;
$ID_Utilisateur = null;

// Recherche de l'utilisateur dans la base de données
$A = "SELECT ID_Utilisateur,type_utilisateur FROM Utilisateurs WHERE nomutilisateur='$identifiant' AND motdepasse='$mot_de_passe'";
$verification = pg_query($A);

if ($verification !== false) {
    $verification2 = pg_fetch_assoc($verification);

    if ($verification2 !== null) {
        $utilisateur_trouve = true;
        $ID_Utilisateur = $verification2['id_utilisateur'];
    }
}

$utilisateur_type=$verification2['type_utilisateur'];

if ($utilisateur_trouve) {
    $_SESSION['ID_Utilisateur'] = $ID_Utilisateur;
    if ($utilisateur_type === 'admin') {
        header("Location: index1.php");
    } elseif ($utilisateur_type === 'adherent') {
        header("Location: index2.php?");
    }
} else {
    // Authentification échouée, affichez un message d'erreur
    echo "Identifiant ou mot de passe incorrect.";
}


// Fermeture de la connexion
pg_close($con);
?>
