<?php
include("connexion.php");
$con = connect();

if (!$con) {
    echo "Problème connexion à la base";
    exit;
}

// Requête pour obtenir les résultats des compétitions
$resultatQuery = "SELECT Score, Adherent.Nom, Adherent.Prenom, NomCompetition
                  FROM Resultat
                  JOIN Adherent ON Resultat.ID_Adherent = Adherent.ID_Adherent";
$resultatResult = pg_query($con, $resultatQuery);

if (!$resultatResult) {
    echo "Problème lors du lancement de la requête pour les résultats";
    exit;
}

echo "<html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta http-equiv='X-UA-Compatible' content='IE=edge'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Résultats des Compétitions Précédentes</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 20px;
                    background-color: #f4f4f4;
                }
                h2 {
                    color: #333;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 12px;
                    text-align: left;
                }
                th {
                    background-color: #e0e0e0;
                    color: #333;
                }
                tr:nth-child(even) {
                    background-color: #f9f9f9;
                }
            </style>
        </head>
        <body>";

echo "<h2>Résultats des Compétitions Précédentes</h2>";
echo "<table>";
echo "<tr><th>Nom Adhérent</th><th>Prénom Adhérent</th><th>Nom Compétition</th><th>Score</th></tr>";

while ($ligneResultat = pg_fetch_assoc($resultatResult)) {
    echo "<tr>";
    echo "<td>" . $ligneResultat['nom'] . "</td>";
    echo "<td>" . $ligneResultat['prenom'] . "</td>";
    echo "<td>" . $ligneResultat['nomcompetition'] . "</td>";
    echo "<td>" . $ligneResultat['score'] . "</td>";
    echo "</tr>";
}

echo "</table>";
echo "</body>
      </html>";

pg_close($con);
?>
