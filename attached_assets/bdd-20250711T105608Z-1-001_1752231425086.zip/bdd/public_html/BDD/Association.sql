-- Suppression des tables existantes
DROP TABLE IF EXISTS Lieu CASCADE;
DROP TABLE IF EXISTS Adherent CASCADE;
DROP TABLE IF EXISTS Intervenant CASCADE;
DROP TABLE IF EXISTS Cours CASCADE;
DROP TABLE IF EXISTS Seance CASCADE;
DROP TABLE IF EXISTS Competition CASCADE;
DROP TABLE IF EXISTS SousCategorie CASCADE;
DROP TABLE IF EXISTS Planning CASCADE;
DROP TABLE IF EXISTS Resultat CASCADE;
DROP TABLE IF EXISTS Presence CASCADE;
DROP TABLE IF EXISTS Utilisateurs CASCADE;
DROP TABLE IF EXISTS estinscrit CASCADE;

-- Création de la table Lieu
CREATE TABLE Lieu (
    Lieu INT PRIMARY KEY,
    Nom_Lieu VARCHAR(255) NOT NULL
);
CREATE TABLE Utilisateurs (
    ID_Utilisateur SERIAL PRIMARY KEY,
    NomUtilisateur VARCHAR(255) ,
    MotDePasse VARCHAR(255) ,
    Type_Utilisateur VARCHAR(255)
);
-- Création de la table Adhérent
CREATE TABLE Adherent (
    ID_Utilisateur INT,
    ID_Adherent INT PRIMARY KEY,
    Nom VARCHAR(255) NOT NULL,
    Prenom VARCHAR(255) NOT NULL,
    Sexe VARCHAR(1) NOT NULL,
    Age INT,
    FOREIGN KEY (ID_Utilisateur) REFERENCES Utilisateurs(ID_Utilisateur)

);

-- Création de la table Cours
CREATE TABLE Cours (
    ID_cours INT PRIMARY KEY,
    nom_Activite VARCHAR(255) NOT NULL
);

-- Création de la table Seance
CREATE TABLE Seance (
    ID_Seance INT PRIMARY KEY,
    Lieu INT,
    ID_cours INT,
    FOREIGN KEY (ID_cours) REFERENCES Cours(ID_cours),
    FOREIGN KEY (Lieu) REFERENCES Lieu(Lieu)
);

-- Création de la table Intervenant
CREATE TABLE Intervenant (
    ID_Utilisateur INT,
    ID_Intervenant INT  PRIMARY KEY,
    ID_Seance INT,
    Nom VARCHAR(255) NOT NULL,
    Prenom VARCHAR(255) NOT NULL,
    FOREIGN KEY (ID_Seance) REFERENCES Seance(ID_Seance),
    FOREIGN KEY (ID_Utilisateur) REFERENCES Utilisateurs(ID_Utilisateur)
);

-- Création de la table Competition
CREATE TABLE Competition (
    NomCompetition VARCHAR(255) PRIMARY KEY,
    Lieu INT,
    Date DATE,
    Categorie VARCHAR(255),
    FOREIGN KEY (Lieu) REFERENCES Lieu(Lieu)
);

-- Création de la table Planning
CREATE TABLE Planning (
    ID_Seance INT,
    Jour VARCHAR(255) NOT NULL,
    Heure VARCHAR(255) NOT NULL,
    PRIMARY KEY (ID_Seance, Jour),
    FOREIGN KEY (ID_Seance) REFERENCES Seance(ID_Seance)
);

-- Création de la table Resultat
CREATE TABLE Resultat (
    Score INT,
    ID_Adherent INT,
    NomCompetition VARCHAR(255),
    PRIMARY KEY (ID_Adherent, NomCompetition),
    FOREIGN KEY (ID_Adherent) REFERENCES Adherent(ID_Adherent),
    FOREIGN KEY (NomCompetition) REFERENCES Competition(NomCompetition)
);

-- Table pour enregistrer la présence des adhérents à chaque séance
CREATE TABLE Presence (
    ID_Presence SERIAL PRIMARY KEY,
    ID_Adherent INT REFERENCES Adherent(ID_Adherent),
    ID_Seance INT REFERENCES Seance(ID_Seance),
    Jour INT,
    Mois INT,
    EstPresent BOOLEAN,
    EstAbsent BOOLEAN
);

CREATE TABLE estinscrit(
    ID_Seance INT,
    ID_Adherent INT,
    FOREIGN KEY (ID_Seance) REFERENCES Seance(ID_Seance),
    FOREIGN KEY (ID_Adherent) REFERENCES Adherent(ID_Adherent)

);




INSERT INTO Utilisateurs(ID_Utilisateur,NomUtilisateur,motdepasse,Type_Utilisateur) VALUES
(1,'SmithJohn','postgres','adherent'),
(2,'BouvierMatiyou','postgres','adherent'),
(3,'CristianoRonaldo','postgres','adherent'),
(4,'KhatraniEmmenne','postgres','adherent'),
(5,'BrownDaniel','postgres','adherent'),
(6,'DavisOlivia','postgres','adherent'),
(7,'LaMortEthan','postgres','adherent'),
(8,'SulekSam','postgres','adherent'),
(9,'TchetcheMatthew','postgres','adherent'),
(10,'TysonMike','postgres','adherent'),
(11,'ZidaneZinedine','postgres','adherent'),
(12,'LenineAhemdou','postgres','adherent'),
(13,'JacksonLily','postgres','adherent'),
(14,'VantorreFrancois','postgres','adherent'),
(15,'BlanciagaChloe','postgres','adherent'),
(16,'SmithAlice','postgres','admin'),
(17,'JonesBob','postgres','admin'),
(18,'LabisLeane','postgres','admin'),
(19,'JdaiaaYoussef','postgres','admin'),
(20,'BrownGrace','postgres','admin'),
(21,'TaylorJohn','postgres','admin'),
(22,'DavisSophia','postgres','admin'),
(23,'MooreEthan','postgres','admin'),
(24,'ElerhabiyeReda','postgres','admin'),
(25,'MartinOlivia','postgres','admin');



INSERT INTO Lieu (Lieu, Nom_Lieu) VALUES
(56, 'Stade Municipal'),     -- Lieu ID 1
(45, 'Piscine Olympique'),   -- Lieu ID 2
(81, 'Centre Sportif'),      -- Lieu ID 3
(42, 'Salle de Gym'),        -- Lieu ID 4
(13, 'Yoga Studio');         -- Lieu ID 5


-- Insertion de 15 Adherents
INSERT INTO Cours (ID_cours, nom_Activite) VALUES
(1, 'Course à Pied'),
(2, 'Natation'),
(3, 'Triathlon'),
(4, 'Gymnastique'),
(5, 'Stretching');

INSERT INTO Seance (ID_Seance, Lieu, ID_cours) VALUES
(1, 56, 1), -- Course à Pied au Stade Municipal
(2, 56, 1),
(3, 45, 2),-- Natation à la Piscine Olympique
(4, 45, 2),
(5, 81, 3), -- Triathlon au Centre Sportif
(6, 81, 3),
(7, 42, 4), -- Gymnastique à la Salle de Gym
(8, 42, 4),
(9, 13, 5), -- Stretching au Yoga Studio
(10, 13, 5);

INSERT INTO Adherent (ID_Utilisateur,ID_Adherent, Nom, Prenom, Sexe, Age) VALUES
(1,1, 'Smith', 'John', 'M', 25),
(2,2, 'Bouvier', 'Matiyou', 'F', 20),
(3,3, 'Cristanio', 'Ronaldo', 'M', 22),
(4,4, 'Khatrani', 'Emmenne', 'F', 28),
(5,5, 'Brown', 'Daniel', 'M', 23),
(6,6, 'Davis', 'Olivia', 'F', 29),
(7,7, 'LaMort', 'Ethan', 'M', 27),
(8,8, 'Sulek', 'Sam', 'F', 26),
(9,9, 'Tchetche', 'Matthew', 'M', 21),
(10,10, 'Tyson', 'Mike', 'M', 24),
(11,11, 'Zidane', 'Zinedine', 'M', 22),
(12,12, 'Lenine', 'Ahemdou', 'M', 23),
(13,13, 'Jackson', 'Lily', 'F', 28),
(14,14, 'Vantorre', 'Francois', 'M', 20),
(15,15, 'Balanciaga', 'Chloe', 'F', 23);






-- Insertion de données dans la table Intervenant
INSERT INTO Intervenant (ID_Seance,ID_Intervenant,ID_Utilisateur, Nom, Prenom) VALUES
(1,16,16, 'Smith', 'Alice'), -- Intervenant for Course à Pied
(2,17,17, 'Jones', 'Bob'),   -- Another Intervenant for Course à Pied
(3,18,18, 'Labis', 'Leane'),  -- Intervenant for Natation
(4,19,19, 'Jdaiaa', 'Youssef'), -- Another Intervenant for Natation
(5,20,20, 'Brown', 'Grace'),  -- Intervenant for Triathlon
(6,21,21, 'Taylor', 'John'),  -- Another Intervenant for Triathlon
(7,22,22, 'Davis', 'Sophia'), -- Intervenant for Gymnastique
(8,23,23, 'Moore', 'Ethan'),  -- Another Intervenant for Gymnastique
(9,24,24, 'Elerhabiye', 'Reda'),   -- Intervenant for Stretching
(10,25,25, 'Martin', 'Olivia');   -- Another Intervenant for Stretching

-- Insertion de données dans la table Competition avec des noms inventés associés à une association sportive
INSERT INTO Competition (NomCompetition, Lieu, Date, Categorie) VALUES
('RunExpress 10K', 56, '2023-05-15', 'Course à Pied'),
('SpeedChallenge 20K', 56, '2023-06-20', 'Course à Pied'),
('SprintFiesta', 56, '2023-07-25', 'Course à Pied'),
('EnduranceFest', 56, '2023-09-10', 'Course à Pied'),
('TriSpeed Thrill', 81, '2023-08-05', 'Triathlon'),
('TriUltimate Challenge', 81, '2023-09-15', 'Triathlon'),
('ExtremeTri Adventure', 81, '2023-10-20', 'Triathlon');




-- Insertion de données dans la table Planning pour chaque adhérent
INSERT INTO Planning (ID_Seance, Jour, Heure) VALUES
--Course à Pied le lundi à 18h
( 1, 'Lundi', '18:00'),
( 2, 'Mardi', '17:00'),


--Natation le mardi à 19h
( 3, 'Mardi', '19:00'),
( 4, 'Jeudi', '16:00'),

--Triathlon le mercredi à 17h
( 5, 'Mercredi', '17:00'),
( 6, 'Vendredi', '17:30'),

--Gymnastique le jeudi à 20h
( 7, 'Jeudi', '20:00'),
( 8, 'Lundi', '18:15'),

--Stretching le vendredi à 18h30
( 9, 'Vendredi', '18:30'),
( 10, 'Mercredi', '18:30');



-- Insertion de données dans la table Resultat avec des noms inventés associés à une association sportive
INSERT INTO Resultat (Score, ID_Adherent, NomCompetition) VALUES
-- Course à Pied 10K
(15, 1, 'RunExpress 10K'),
(17, 2, 'RunExpress 10K'),
(20, 3, 'RunExpress 10K'),

-- Course à Pied 20K
(18, 4, 'SpeedChallenge 20K'),
(20, 5, 'SpeedChallenge 20K'),
(19, 6, 'SpeedChallenge 20K'),

-- Semi-Marathon
(16, 7, 'SprintFiesta'),
(18, 8, 'SprintFiesta'),
(17, 9, 'SprintFiesta'),

-- Marathon
(14, 10, 'EnduranceFest'),
(16, 11, 'EnduranceFest'),
(15, 12, 'EnduranceFest'),

-- Triathlon Sprint
(12, 13, 'TriSpeed Thrill'),
(15, 14, 'TriSpeed Thrill'),
(14, 15, 'TriSpeed Thrill');

INSERT INTO estinscrit (ID_Seance, ID_Adherent) VALUES
(1, 1), (1, 2), (1, 3), (1, 4),
(2, 5), (2, 6), (2, 7), (2, 8),
(3, 9), (3, 10), (3, 11), (3, 12),
(4, 13), (4, 14), (4, 15), (4, 1),
(5, 2), (5, 3), (5, 4), (5, 5),
(6, 6), (6, 7), (6, 8), (6, 9),
(7, 10), (7, 11), (7, 12), (7, 13),
(8, 14), (8, 15), (8, 1), (8, 2),
(9, 3), (9, 4), (9, 5), (9, 6),
(10, 7), (10, 8), (10, 9), (10, 10);





