<?php
function connect()
{
$con=pg_connect("host=serveur-etu.polytech-lille.fr user=izarouri port=5432 password=postgres dbname=Association") ;
return $con;
}
?>
