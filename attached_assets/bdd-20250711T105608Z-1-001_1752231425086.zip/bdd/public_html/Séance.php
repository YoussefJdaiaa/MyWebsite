<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Séances</title>
    <style>
        /* General styling */
        body {
            background: linear-gradient(145deg, #575757, #333333);
            color: #ffffff;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        header {
            width: 100%;
            background-color: rgba(51, 51, 51, 0.85);
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.2);
        }

        header h1 {
            font-size: 2.5em;
            color: #ECF0F1;
        }

        /* Styling for the main container */
        .container {
            background-color: rgba(51, 51, 51, 0.9);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            max-width: 800px;
            width: 90%;
            margin-top: 30px;
        }

        /* Styling for headings */
        h2 {
            color: #ECF0F1;
            font-size: 1.8em;
            margin-bottom: 15px;
            text-align: center;
            padding-bottom: 10px;
            border-bottom: 2px solid #67D8F2;
        }

        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #505050;
            color: #ffffff;
        }

        tr:nth-child(even) {
            background-color: #404040;
        }

        /* Form styling */
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: center;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #ECF0F1;
        }

        input, select {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 10px;
            border: none;
            border-radius: 5px;
            background-color: #505050;
            color: #ffffff;
        }

        input[type="submit"] {
            background-color: #67D8F2;
            color: #333;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #2C3E50;
        }
    </style>
</head>
<body>

<header>
    <h1>Liste des Séances</h1>
</header>

<?php
include("connexion.php");
$con = connect();

if (!$con) {
    echo "Problème connexion à la base";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submitAdherent"])) {
    $idSeance = $_POST["seance"];
    $idAdherent = $_POST["adherent"];

    $sqlCheckInscription = "SELECT COUNT(*) FROM EstInscrit WHERE ID_Adherent = $idAdherent AND ID_Seance = $idSeance";
    $resultCheckInscription = pg_query($con, $sqlCheckInscription);
    if (!$resultCheckInscription) {
        echo "Problème lors de la vérification de l'inscription de l'adhérent";
        exit;
    }

    $rowCheckInscription = pg_fetch_assoc($resultCheckInscription);
    if ($rowCheckInscription['count'] == 0) {
        $sqlInsertInscrit = "INSERT INTO EstInscrit (ID_Adherent, ID_Seance) VALUES ($idAdherent, $idSeance)";
        $resultInsertInscrit = pg_query($con, $sqlInsertInscrit);
        if (!$resultInsertInscrit) {
            echo "Problème lors de l'ajout de l'adhérent à la séance";
            exit;
        } else {
            echo "<p>Adhérent ajouté à la séance avec succès!</p>";
        }
    } else {
        echo "<p>L'adhérent est déjà inscrit à cette séance.</p>";
    }
}

$sqlSeances = "SELECT DISTINCT Planning.ID_Seance, Lieu.Nom_Lieu, Cours.nom_Activite, Planning.Jour, Planning.Heure FROM Planning NATURAL JOIN Seance NATURAL JOIN Lieu NATURAL JOIN Cours";
$resultatSeances = pg_query($con, $sqlSeances);
if (!$resultatSeances) {
    echo "Problème lors du lancement de la requête pour la liste des séances";
    exit;
}
?>
<div class="container">
    <h2>Liste des Séances</h2>
    <?php
    while ($rowSeance = pg_fetch_assoc($resultatSeances)) {
        echo "<div class='seance-container'>";
        echo "<table>";
        echo "<tr>";
        echo "<th>ID Séance</th>";
        echo "<th>Lieu</th>";
        echo "<th>Nom du Cours</th>";
        echo "<th>Jour</th>";
        echo "<th>Heure</th>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>" . htmlspecialchars($rowSeance['id_seance']) . "</td>";
        echo "<td>" . htmlspecialchars($rowSeance['nom_lieu']) . "</td>";
        echo "<td>" . htmlspecialchars($rowSeance['nom_activite']) . "</td>";
        echo "<td>" . htmlspecialchars($rowSeance['jour']) . "</td>";
        echo "<td>" . htmlspecialchars($rowSeance['heure']) . "</td>";
        echo "</tr>";
        echo "</table>";
        echo "</div>";
    }
    ?>

    <h2>Ajouter un Adhérent à une Séance</h2>
    <form method="post" action="">
        <label for="seance">Séance :</label>
        <select name="seance" id="seance">
            <?php
            $resultatSeances = pg_query($con, $sqlSeances);  // Re-fetching for form dropdown
            while ($rowSeance = pg_fetch_assoc($resultatSeances)) {
                echo "<option value='" . htmlspecialchars($rowSeance['id_seance']) . "'>" . htmlspecialchars($rowSeance['nom_activite']) . " - " . htmlspecialchars($rowSeance['jour']) . " " . htmlspecialchars($rowSeance['heure']) . "</option>";
            }
            ?>
        </select>

        <label for="adherent">Adhérent :</label>
        <select name="adherent" id="adherent">
            <?php
            $sqlAdherents = "SELECT ID_Adherent, Nom, Prenom FROM Adherent";
            $resultatAdherents = pg_query($con, $sqlAdherents);
            while ($rowAdherent = pg_fetch_assoc($resultatAdherents)) {
                echo "<option value='" . htmlspecialchars($rowAdherent['id_adherent']) . "'>" . htmlspecialchars($rowAdherent['nom']) . " " . htmlspecialchars($rowAdherent['prenom']) . "</option>";
            }
            ?>
        </select>
        <input type="submit" name="submitAdherent" value="Ajouter Adhérent">
    </form>
</div>

</body>
</html>
